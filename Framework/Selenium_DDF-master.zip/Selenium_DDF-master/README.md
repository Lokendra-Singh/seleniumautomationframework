# Selenium_DDF
Selenium Data Driven Framework For Automating Any Application

Data Driven Automation testing allows you to run a test case multiple times with different input parameters. 

As Selenium Webdriver is more an Automation testing framework than a ready-to-use tool, you will have to put in some effort to support data driven testing in your automated tests. 

I usually prefer to use Microsoft Excel as the format for storing my parameters. 

An additional advantage of using Excel is that you can easily outsource the test data administration to someone other than yourself, someone who might have better knowledge of the test cases that need to be run and the parameters required to execute them.

My Above framework consists of an excel sheet containing testdata.xlsx which contains test data which is seperated out from the main code and further while execution the data is mapped with the parameters and execution starts. 

You can customise this framework for your application and start executing Automation scripts.
